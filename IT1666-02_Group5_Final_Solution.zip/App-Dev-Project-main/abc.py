a = ['a', 'b', 'c']
b = ['a', 'c', 'd']

for i in a:
    if i in b:
        print('nice')

