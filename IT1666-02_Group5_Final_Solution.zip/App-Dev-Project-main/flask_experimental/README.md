Trying something here with a template
